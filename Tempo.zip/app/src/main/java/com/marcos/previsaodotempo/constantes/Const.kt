package com.marcos.previsaodotempo.constantes

object Const {
    const val API_KEY = "c49d43bcadaa525509643f4330c34bd3"

}