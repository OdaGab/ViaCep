package com.marcos.previsaodotempo.model

data class Weather(
    val main: String,
    val description: String
)
